package com.example.bloatedTweetServices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BloatedTweetServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(BloatedTweetServicesApplication.class, args);
	}

}
