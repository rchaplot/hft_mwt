package com.example.bloatedTweetServices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BloatedTweetServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
