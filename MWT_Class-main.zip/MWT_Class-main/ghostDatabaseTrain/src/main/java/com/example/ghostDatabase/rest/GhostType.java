package com.example.ghostDatabase.rest;

public enum GhostType {
  POLTERGEIST,MAAR,REVANENT,JIN
}
