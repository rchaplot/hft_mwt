package com.example.ghostDatabase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GhostDatabaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(GhostDatabaseApplication.class, args);
	}

}
