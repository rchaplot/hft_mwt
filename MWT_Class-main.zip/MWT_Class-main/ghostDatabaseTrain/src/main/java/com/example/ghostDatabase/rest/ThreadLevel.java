package com.example.ghostDatabase.rest;

public enum ThreadLevel {
  HIGH,
  MEDIUM,
  LOW
}
