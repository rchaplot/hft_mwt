package com.example.ghostDatabase;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GhostDatabaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
